# Example Python Code to Insert a Document 

from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        """
        Initialize MongoDB connection using provided credentials.
        """

        # Connection variables
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        try:
            # Create MongoDB client (auth happens in the admin database)
            self.client = MongoClient(
                f'mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin'
            )

            # Access database and collection
            self.database = self.client[DB]
            self.collection = self.database[COL]

        except Exception as e:
            print(f"MongoDB connection error: {e}")
            self.client = None
            self.database = None
            self.collection = None

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        """Insert a document into the animals collection.

        Args:
            data (dict): Key/value pairs representing the document to insert.

        Returns:
            bool: True if insert succeeds, otherwise False.
        """
        if data is None:
            return False

        try:
            result = self.collection.insert_one(data)  # data must be a dict
            return result.acknowledged
        except Exception as e:
            print(f"Create error: {e}")
            return False


    # Create method to implement the R in CRUD.
    def read(self, query):
        """Query documents from the animals collection.

        Args:
            query (dict): Key/value pairs used as MongoDB filter.

        Returns:
            list: List of matching documents, or empty list if none found.
        """
        if query is None:
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"Read error: {e}")
            return []

    # Update method to implement the U in CRUD.
    def update(self, query, new_values):
        """Update document(s) in the animals collection.

        Args:
            query (dict): Key/value pairs used as MongoDB filter.
            new_values (dict): Fields to update.

        Returns:
            int: Number of documents modified.
        """
        if query is None or new_values is None:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print(f"Update error: {e}")
            return 0

    # Delete method to implement the D in CRUD.
    def delete(self, query):
        """Delete document(s) from the animals collection.

        Args:
            query (dict): Key/value pairs used as MongoDB filter.

        Returns:
            int: Number of documents deleted.
        """
        if query is None:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete error: {e}")
            return 0





